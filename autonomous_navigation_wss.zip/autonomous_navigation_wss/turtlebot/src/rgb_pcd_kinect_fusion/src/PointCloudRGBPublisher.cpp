/****
 https://forum.coppeliarobotics.com/viewtopic.php?t=7617
 https://forum.coppeliarobotics.com/viewtopic.php?t=7450
 ****/
/***
 Author: Li Jue Kun
 ****/

#include <string>
#include <vector>
#include <ros/ros.h>

#include <std_msgs/Float32MultiArray.h>

#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <sensor_msgs/point_cloud2_iterator.h>
#include <pcl_conversions/pcl_conversions.h>

#include <typeinfo>

#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>

#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

// static const std::string OPENCV_WINDOW = "Image window";

struct SPointCloudPublisherData 
{
	sensor_msgs::PointCloud2 pointcloud;
	
	SPointCloudPublisherData(const std::string frame_id)
	{
		pointcloud.header.frame_id = frame_id;
		pointcloud.fields.resize(3);
		pointcloud.fields[0].name="x";
		pointcloud.fields[0].offset=0; 
		pointcloud.fields[0].datatype=sensor_msgs::PointField::FLOAT32;
		pointcloud.fields[0].count=1;
		pointcloud.fields[1].name="y";
		pointcloud.fields[1].offset=4; 
		pointcloud.fields[1].datatype=sensor_msgs::PointField::FLOAT32;
		pointcloud.fields[1].count=1;
		pointcloud.fields[2].name="z";
		pointcloud.fields[2].offset=8; 
		pointcloud.fields[2].datatype=sensor_msgs::PointField::FLOAT32;
		pointcloud.fields[2].count=1;
		pointcloud.point_step = 12;
		pointcloud.height = 1;
		pointcloud.width = 0; // To be updated
		pointcloud.row_step = 0; // To be updated
		pointcloud.is_bigendian = false;
		pointcloud.is_dense = true;
	}
};

struct SDepthCloudPublisherData : public SPointCloudPublisherData
{
    std::vector<float> x_scale;
    std::vector<float> y_scale;
	SDepthCloudPublisherData(const std::string frame_id) : SPointCloudPublisherData(frame_id)
	{
        pointcloud.fields.resize(4);
        pointcloud.fields[3].name="rgb";
        pointcloud.fields[3].offset=12; 
        pointcloud.fields[3].datatype=sensor_msgs::PointField::UINT32;
        pointcloud.fields[3].count=1;
        pointcloud.point_step = 16;
	}
};

typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::CameraInfo> MyPolicy;

template<typename T>
T getParam(ros::NodeHandle& n, const std::string& name, const T& defaultValue)
{
    T v;
    if (n.getParam(name, v))
    {
        ROS_INFO_STREAM("Found parameter: " << name << ", value: " << v);
        return v;
    }
    else
    {
        ROS_WARN_STREAM("Cannot find value for parameter: " << name << ", assigning default: " << defaultValue);
    }
    return defaultValue;
}

class PointCloudRGBPublisher
{
	typedef pcl::PointXYZRGB Point;
	typedef pcl::PointCloud<Point> Cloud;
	typedef std_msgs::Float32MultiArray MultiArray;
        
private:

	ros::NodeHandle n_;
	std::string image_sub_topic_name;
	std::string camera_info_sub_topic_name;
	std::string pcd_color_topic;
	
	std::string pcd_multiarray_topic_name;
	
	float far_clip;
    float near_clip; 
	
protected:
	ros::NodeHandle node;
    
    
public:

	MyPolicy* policy;
	message_filters::Synchronizer<MyPolicy>* sync_;
    message_filters::Subscriber<sensor_msgs::Image> image_sub_;
    message_filters::Subscriber<sensor_msgs::CameraInfo> camera_info_sub_;
    ros::Publisher color_pcl_pub_;
    
    
    PointCloudRGBPublisher(): n_("~"),
    policy(new MyPolicy(10)), 
    sync_(new message_filters::Synchronizer<MyPolicy>(*policy))
    {
        
		image_sub_topic_name = getParam<std::string>(n_, "image_sub_topic_name", "/camera/rgb");
		camera_info_sub_topic_name = getParam<std::string>(n_, "camera_info_sub_topic_name", "/camera/rgb/camera_info");
		pcd_multiarray_topic_name = getParam<std::string>(n_, "pcd_multiarray_topic_name", "/camera/depth");
		
		image_sub_.subscribe(node,image_sub_topic_name,1); 
		camera_info_sub_.subscribe(node,camera_info_sub_topic_name,1); 
		
		sync_->connectInput(image_sub_,camera_info_sub_); 
		sync_->registerCallback(&PointCloudRGBPublisher::callback,this);
		
		pcd_color_topic = getParam<std::string>(n_, "pcd_color_topic", "/pcd");
        color_pcl_pub_ = node.advertise<sensor_msgs::PointCloud2>(pcd_color_topic, 10);
        
        far_clip = getParam<double>(n_, "far_clip", 3.5);
        near_clip = getParam<double>(n_, "near_clip", 0.01);
		
		// cv::namedWindow(OPENCV_WINDOW);
        
    }
    
    ~PointCloudRGBPublisher() {}
    
    void callback(const sensor_msgs::ImageConstPtr& image, const sensor_msgs::CameraInfoConstPtr& cam_info)
	{
		// Solve all of perception here...
		
		std_msgs::Float32MultiArray::ConstPtr recent_cloud = ros::topic::waitForMessage<std_msgs::Float32MultiArray>(pcd_multiarray_topic_name, node, ros::Duration(1.0));
            
        while (!recent_cloud){
			ROS_INFO("Wait: Waiting for point cloud2 and image");
			recent_cloud = ros::topic::waitForMessage<std_msgs::Float32MultiArray>(pcd_multiarray_topic_name, node, ros::Duration(1.0));
		}
		
		// ROS_INFO("Total [%d]", (int)recent_cloud->data.size()); 
	
	
		cv_bridge::CvImagePtr cv_ptr;
				
		try
		{
		  cv_ptr = cv_bridge::toCvCopy(image, sensor_msgs::image_encodings::BGR8);
		}
		catch (cv_bridge::Exception& e)
		{
		  ROS_ERROR("cv_bridge exception: %s", e.what());
		  return;
		}
		
		// cv::imshow(OPENCV_WINDOW, cv_ptr->image);
		// cv::waitKey(3);
		
		if (cv_ptr->image.cols != cam_info->width or cv_ptr->image.rows != cam_info->height or recent_cloud->data.size() != cam_info->width * cam_info->height) {
			
			std::cout << "rgb and depth image size mismatch" << '\n';
			
			exit(0);
		}
		
		
		
		// SDepthCloudPublisherData* pcd = new SDepthCloudPublisherData("kinect_depth_frame"); 
		SDepthCloudPublisherData* pcd = new SDepthCloudPublisherData("camera_depth_frame");
		int resol_x = cam_info->width;
		int resol_y = cam_info->height;
		float scale = (far_clip-near_clip)/1.0;
		
		unsigned int datalen = resol_x * resol_y;
		if (pcd->x_scale.size() != datalen) {
			// First run, we need to initialise the scaling factors
			pcd->pointcloud.data.resize(datalen*pcd->pointcloud.point_step);
			pcd->x_scale.resize(datalen);
			pcd->y_scale.resize(datalen);
			// float f = (resol_x/2.) / tan(view_angle/2.);
			float f = cam_info->K[0];
			for (int j=0;j<resol_y;j++){
				float y = (j - resol_y/2.0);
				for (int i=0;i<resol_x;i++){
					int k = j*resol_x + i;
					float x = -(i - resol_x/2.0);
					pcd->x_scale[k] = x / f;
					pcd->y_scale[k] = y / f;
				}
			}
		}
		
		for (unsigned int i=0;i<datalen;i++){
			float depth = near_clip + scale * recent_cloud->data[i];
			float xyz[3] = {depth*pcd->x_scale[i],depth*pcd->y_scale[i],depth};
			assert(sizeof(xyz)==12);
			uint8_t * raw = (uint8_t*)xyz;
			std::copy(raw,raw+12,pcd->pointcloud.data.begin()+i*pcd->pointcloud.point_step);
			// unsigned int p = i*3;
			// uint8_t argb[4] = {image_buf[p+2],image_buf[p+1],image_buf[p],0};
			// std::copy(argb,argb+4,pcd->pointcloud.data.begin()+i*pcd->pointcloud.point_step+12);
		}
		
		pcd->pointcloud.width = resol_x;
		pcd->pointcloud.height = resol_y;
		pcd->pointcloud.row_step = resol_x * pcd->pointcloud.point_step;
		pcd->pointcloud.header.stamp = image->header.stamp;
		// pub.generalPublisher.publish(pcd->pointcloud);
		color_pcl_pub_.publish(pcd->pointcloud);

/*		
		Cloud::Ptr cloud(new Cloud);
		
		for (size_t u = 0; u < cam_info->height; u++) {
			
			for (size_t v = 0; v < cam_info->width; v++) {
				
				cv::Vec3b rgb_ints = cv_ptr->image.at<cv::Vec3b>(u, v);
				
				int w = cam_info->width * u + v;
				
				float z = far_clip * recent_cloud->data[w] + near_clip;
				
				float y = (u - cam_info->height / 2) * z / cam_info->K[0];
            
				float x = (v - cam_info->width / 2) * z / cam_info->K[0];
				
				Point p;
				
				p.x = x, p.y = y, p.z = z;
				
				p.r = (int) rgb_ints[0]; p.g = (int) rgb_ints[1]; p.b = (int) rgb_ints[2];
				
				cloud->points.push_back(p);
			}
			
		}
		
		cloud->header.frame_id = "kinect_depth";
		cloud->width = cloud->points.size();
		cloud->height = 1;
		
		sensor_msgs::PointCloud2::Ptr outMsg(new sensor_msgs::PointCloud2());
		pcl::toROSMsg(*cloud, *outMsg);
		outMsg->header.stamp = image->header.stamp;
		outMsg->header.frame_id = cloud->header.frame_id;
		color_pcl_pub_.publish(*outMsg);
		
*/		
	}

    
/*
	Cloud::Ptr img2cloud(cv::Mat rgb, MultiArray depth_msg)
	{
		std::vector<float> depth = depth_msg.data;
		// std::cout << "rgb.cols: " << rgb.cols << std::endl;
		// std::cout << "v_res: " << v_res << std::endl;
		// std::cout << "rgb.rows: " << rgb.rows << std::endl;
		// std::cout << "u_res: " << v_res << std::endl;
		
		if (rgb.cols != v_res or rgb.rows != u_res or depth.size() != u_res * v_res) {
			
			std::cout << "rgb and depth image size mismatch" << '\n';
			
			exit(0);
		}
		
		Cloud::Ptr cloud(new Cloud);
		
		for (size_t u = 0; u < u_res; u++) {
			
			for (size_t v = 0; v < v_res; v++) {
				
				cv::Vec3b rgb_ints = rgb.at<cv::Vec3b>(u, v);
				
				int w = v_res * u + v;
				
				// float z = far_clip * depth[w] + near_clip;
				float z = (far_clip-near_clip)*(1 - depth[w]) + near_clip;
				
				// float y = (u - u_res / 2) * z / focal_length;
				
				// float x = (v - v_res / 2) * z / focal_length;
				
				float y = z * sin((v-v_res/2) * focal_length / v_res);
				float x = z * sin((u-u_res/2) * focal_length / u_res);
				
				Point p;
				
				p.x = x, p.y = y, p.z = z;
				
				p.r = (int) rgb_ints[0]; p.g = (int) rgb_ints[1]; p.b = (int) rgb_ints[2];
				
				cloud->points.push_back(p);
			}
		}
		
		cloud->header.frame_id = "kinect_depth_frame";
		cloud->width = cloud->points.size();
		cloud->height = 1;
		
		return cloud;
	}
*/
    
/*    
    void imageCb(const sensor_msgs::ImageConstPtr& msg){
        
            
            std_msgs::Float32MultiArray::ConstPtr recent_cloud = ros::topic::waitForMessage<std_msgs::Float32MultiArray>(pcl_topic, nh_, ros::Duration(1.0));
            
            while (!recent_cloud){
                ROS_INFO("Wait: Waiting for point cloud2 and image");
                std_msgs::Float32MultiArray::ConstPtr recent_cloud = ros::topic::waitForMessage<std_msgs::Float32MultiArray>(pcl_topic, nh_, ros::Duration(1.0));
            }
            
            
            
            cv_bridge::CvImagePtr cv_ptr;
            
			try
			{
			  cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
			}
			catch (cv_bridge::Exception& e)
			{
			  ROS_ERROR("cv_bridge exception: %s", e.what());
			  return;
			}
			
			Cloud::Ptr cloud(new Cloud);
			cloud = img2cloud(cv_ptr->image, *recent_cloud);
			
			sensor_msgs::PointCloud2::Ptr outMsg(new sensor_msgs::PointCloud2());
			pcl::toROSMsg(*cloud, *outMsg);
			outMsg->header.stamp = msg->header.stamp;
			outMsg->header.frame_id = msg->header.frame_id;
			color_pcl_pub_.publish(*outMsg);
        
    }
*/
    
};


int main(int argc, char **argv){
	
    ros::init(argc, argv, "pcd_from_multiarray");
    
    PointCloudRGBPublisher node;
    
    ros::spin();
    
    return 0;
}

